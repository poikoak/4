﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ivanov_WF_FileManager
{
    public class FileItem
    {
        string fullpath = "";
        string extension = "";
        long size = 0;

        public string Fullpath
        {
            get { return fullpath; }
            set { fullpath = value; }
        }

        public string Extension
        {
            get { return extension; }
            set { extension = value; }
        }

        public long Size
        {
            get { return size; }
            set { size = value; }
        }

        public FileItem(string _fullpath, long _size)
        {
            this.fullpath = _fullpath;
            this.extension = Path.GetExtension(fullpath);
            this.size = _size;
        }
    }
}

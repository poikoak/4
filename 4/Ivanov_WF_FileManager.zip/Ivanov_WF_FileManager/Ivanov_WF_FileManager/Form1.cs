﻿using System;
using System.Collections.Specialized;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

/*1.  Разработать файлойвый менеджер, который имеет следующие функции:
    - 3 панели (дерево, список файлов, предпросмотр для картинок и текста)  +
    - верхнее меню, строка состояния внизу                                  +
    - использование Drag-N-Drop                                             +
    - копирование, перенос, удаление файлов                                 +
    - создание файла и папки                                                +
    - использование клавиатуры                                              +
    - просмотр файлов                                                       +
    - поиск файлов и папок                                                  -
*/

namespace Ivanov_WF_FileManager
{
    public partial class Form1 : Form
    {
        private Bitmap bitmap;
        private ImageList imglist;
        //путь текущей открытой папки
        string currentFolderPath = "";
        //скопировать или вырезать в буфер обмена
        bool copiedToClipboard;

        public Form1()
        {
            InitializeComponent();
            pictureBox1.AllowDrop = true;

            //НАЧАЛЬНАЯ НАСРОЙКА listView ДЛЯ ПОКАЗА ФАЙЛОВ
            try
            {
                listView1.View = View.Details;
                listView1.LargeImageList = new ImageList();
                listView1.SmallImageList = new ImageList();

                listView1.LargeImageList.ImageSize = new Size(48, 48);
                listView1.LargeImageList.Images.Add(Bitmap.FromFile("pict_empty_file.ico"));
                listView1.SmallImageList.Images.Add(Bitmap.FromFile("pict_empty_file.ico"));

                listView1.Columns.Add("Name", 200, HorizontalAlignment.Left);
                listView1.Columns.Add("Date", 146, HorizontalAlignment.Left);
                listView1.Columns.Add("Size", 100, HorizontalAlignment.Left);

                //создание списка изображений 
                imglist = new ImageList();

                //добавление иконок в список изображений
                imglist.Images.Add(Bitmap.FromFile("pict_folder_closed.ico"));
                imglist.Images.Add(Bitmap.FromFile("pict_folder_opened.ico"));
                imglist.Images.Add(Bitmap.FromFile("pict_empty_file.ico"));
                imglist.Images.Add(Bitmap.FromFile("pict_text_file.ico"));
                imglist.Images.Add(Bitmap.FromFile("pict_hdd.ico"));

                //установка списка загруженных картинок для listView
                treeView1.ImageList = imglist;

                //переменная для стандартного рисунка, который будет показываться тогда когда файл не является рисунком
                bitmap = (Bitmap)Bitmap.FromFile("pict_none_file.png");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "ImageList error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Application.Exit();
            }

            //НАЧАЛЬНАЯ НАСТРОЙКА ДЕРЕВА ПАПОК
            //метод для получения списка логических дисков
            string[] drives = Directory.GetLogicalDrives();

            //перебор списка дисков
            foreach (string drive in drives)
            {
                //создание конкретного узла и назначение иконок
                TreeNode node = new TreeNode(drive, 4, 4);
                //добавили готовый узел к дереву	
                treeView1.Nodes.Add(node);
                //заполнение узлов с дисками
                FillByDirectories(node);
            }
        }

        //----------------------------------------------------------------------------------------
        //FillByDirectories - заполнение узлов дерева содержимым каталога	
        private void FillByDirectories(TreeNode node)
        {
            try
            {
                //в node.FullPath - находится полный путь к ветке
                DirectoryInfo dirinfo = new DirectoryInfo(node.FullPath);
                //получение информации о каталогах
                DirectoryInfo[] dirs = dirinfo.GetDirectories();

                //ОЧИЩАЮ дерево, потому что, если не очистить его, то могут появится дубликаты при повторном нажатии
                //данный способ - тоже не является корректным, так как при выборе узла ступеней выше
                //прийдется обновлять нижний узел (нажимать на плюс еще раз)
                node.Nodes.Clear();

                //обработка информации
                foreach (DirectoryInfo dir in dirs)
                {   
                    TreeNode tree = new TreeNode(dir.Name, 0, 1);
                    node.Nodes.Add(tree);
                }
            }
            //исключение будет генерироваться  например для дисковода, если там нет диска	
            catch { }
        }

        //----------------------------------------------------------------------------------------
        //ДЕРЕВО ПАПОК (развертывание)
        //метод запускается ДО открытия узловой ветки дерева
        private void treeView1_BeforeExpand(object sender, TreeViewCancelEventArgs e)
        {
            //запрет постоянной перерисовки дерева во время добавления элементов
            treeView1.BeginUpdate();
            //добавление элементов в дерево
            try
            {
                //перебор всех дочерних узлов для узла, который разворачивается по нажатию "+"
                foreach (TreeNode node in e.Node.Nodes)
                    FillByDirectories(node);
            }
            catch { }
            //возврат режима обычного обновления дерева (сразу вызывает перерисовку дерева)
            treeView1.EndUpdate();
        }

        //метод запускается после выделения узловой ветки дерева
        private void treeView1_AfterSelect(object sender, TreeViewEventArgs e)
        {
            try
            {
                currentFolderPath = e.Node.FullPath;
                FillByFiles(e.Node.FullPath);
            }
            catch (Exception ex)
            { }
        }

        //FillByFiles - заполнение listView файлами
        private void FillByFiles(string path)
        {
            listView1.BeginUpdate();
            listView1.Items.Clear();

            DirectoryInfo dirinfo = new DirectoryInfo(path);
            FileInfo[] files = dirinfo.GetFiles();
            DirectoryInfo[] dirs = dirinfo.GetDirectories();
            
            //обработка информации
            listView1.LargeImageList.Images.Clear();
            listView1.SmallImageList.Images.Clear();
            int iconindex = 0;
            listView1.LargeImageList.Images.Add(Bitmap.FromFile("pict_folder_closed.ico"));
            listView1.SmallImageList.Images.Add(Bitmap.FromFile("pict_folder_closed.ico"));

            //перебрать все ПАПКИ и показать в listView
            foreach (DirectoryInfo dir in dirs)
            {
                ListViewItem item = new ListViewItem(dir.Name);

                //добавить эту иконку в список картинок
                listView1.LargeImageList.Images.Add(Bitmap.FromFile("pict_folder_closed.ico"));
                listView1.SmallImageList.Images.Add(Bitmap.FromFile("pict_folder_closed.ico"));
                iconindex++;

                //указать номер иконки для listView
                item.ImageIndex = iconindex;

                //добавить пукт в listView
                item.SubItems.Add(dir.LastWriteTime.ToString());
                listView1.Items.Add(item);
            }

            //перебрать все ФАЙЛЫ и показать в listView
            foreach (FileInfo file in files)
            {
                ListViewItem item = new ListViewItem(file.Name);

                //записываем в tag полный путь к файлу (используется для drag-n-drop)
                item.Tag = file.FullName;

                //получить иконку для текущего файла
                Icon icon = Icon.ExtractAssociatedIcon(file.FullName);

                //добавить эту иконку в список картинок
                listView1.LargeImageList.Images.Add(icon);
                listView1.SmallImageList.Images.Add(icon);
                iconindex++;

                //указать номер иконки для listView
                item.ImageIndex = iconindex;

                //добавить пукт в listView
                item.SubItems.Add(file.LastWriteTime.ToString());
                item.SubItems.Add(file.Length.ToString());
                listView1.Items.Add(item);
            }
            toolStripStatusLabel1.Text = $"Elements: {iconindex.ToString()}";
            listView1.EndUpdate();
        }     

        //----------------------------------------------------------------------------------------
        //Drag-N-Drop 

        //picturebox1 или textbox1 - запускается, когда пользователь затащил что-то в область
        private void pictureBox1andTextBox1_DragEnter(object sender, DragEventArgs e)
        {
            if ((e.AllowedEffect & DragDropEffects.Copy) != 0)
                e.Effect = DragDropEffects.Copy;
        }

        //picturebox1 или textbox1 - запускается в ответ на отпускание кнопки мыши при перетаскивании
        private void pictureBox1andTextBox1_DragDrop(object sender, DragEventArgs e)
        {
            //если перетаскивается картинка
            if (e.Data.GetDataPresent(DataFormats.Bitmap))
            {
                pictureBox1.Visible = true;
                Image img = (Image)e.Data.GetData(DataFormats.Bitmap);
                pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
                pictureBox1.Image = img;
            }
            //если перетащили файл - показать его содержимое
            else if (e.Data.GetDataPresent(DataFormats.FileDrop))
            {
                string[] str = (string[])e.Data.GetData(DataFormats.FileDrop);
                string txt = File.ReadAllText(str[0]);
                textBox1.Text = txt;
                pictureBox1.Visible = false;
            }
        }

        //инициирование перетаскивания ИЗ listBox
        private void listView1_MouseDown(object sender, MouseEventArgs e)
        {
            // Если есть выделенные строки
            if (listView1.SelectedItems.Count != 0)
            {
                //получить Tag, который записан для каждого Item в listView, и который содержит в себе полный путь к файлу
                string str = (string)listView1.SelectedItems[0].Tag;

                //создать контейнер для хранения данных
                DataObject data1 = new DataObject();

                //положить содержимое выделенной в списке строки
                StringCollection col = new StringCollection();
                col.Add(str);
                data1.SetFileDropList(col);

                //если выделено имя файла картинки - положить картинку в контейнер
                string ext = Path.GetExtension(str);
                if (ext == ".bmp" || ext == ".jpg" || ext == ".gif" || ext == ".png")
                {
                    Image img = Bitmap.FromFile(str);
                    data1.SetImage(img);
                }

                //НАЧАТЬ перетаскивание програмно
                DragDropEffects dde = DoDragDrop(data1, DragDropEffects.Copy);
            }
        }

        //----------------------------------------------------------------------------------------
        //МЕНЮ

        //status-bar
        private void listView1_ItemSelectionChanged(object sender, ListViewItemSelectionChangedEventArgs e)
        {
            toolStripStatusLabel2.Text = $"    Selected elements: {listView1.SelectedItems.Count.ToString()}";
        }

        //exit
        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        //закрытие окна
        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            e.Cancel = false;
        }

        //about
        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            About about = new About();
            about.Owner = this;
            DialogResult res = about.ShowDialog();
        }

        //open file
        //реализовать открытие по двойному клику не удалось, поэтому файлы открываются по нажатию кнопки в меню
        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < listView1.SelectedItems.Count; i++)
            {
                //решение относительно папки - не правильное, папка открывается в стандартном проводнике Windows
                string folderPath = currentFolderPath + @"\" + listView1.SelectedItems[i].Text;
                FileAttributes attr = File.GetAttributes(folderPath);
                if ((attr & FileAttributes.Directory) == FileAttributes.Directory)
                    Process.Start(folderPath);

                //открытие файла в ассоциативном приложении
                if (File.Exists((string)listView1.SelectedItems[i].Tag))
                    Process.Start((string)listView1.SelectedItems[i].Tag);
            }
        }

        //create file
        private void createFileToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //создаем абсолютно пустой файл без расширения
            string name = @"\New file";
            string current = name;
            int i = 0;
            while (File.Exists(currentFolderPath + current))
            {
                i++;
                current = String.Format("{0} {1}", name, i);
            }
            using (File.Create(currentFolderPath + current)) ;
            FillByFiles(currentFolderPath);
        }

        //create folder
        private void createFolderToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string name = @"\New folder";
            string current = name;
            int i = 0;
            while (Directory.Exists(currentFolderPath + current))
            {
                i++;
                current = String.Format("{0} {1}", name, i);
            }
            Directory.CreateDirectory(currentFolderPath + current);
            FillByFiles(currentFolderPath);
        }

        //delete files
        private void deleteToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Are you sure you want to delete files?", "Deleting files", MessageBoxButtons.YesNo);
            if (result == DialogResult.Yes)
            {
                //удаляем выделенные файлы
                for (int i = 0; i < listView1.SelectedItems.Count; i++)
                {
                    //проверяем, является ли выделенный элемент  папкой
                    string folderPath = currentFolderPath + @"\" + listView1.SelectedItems[i].Text;
                    FileAttributes attr = File.GetAttributes(folderPath);
                    if ((attr & FileAttributes.Directory) == FileAttributes.Directory)
                        Directory.Delete(folderPath);

                    //проверяем, является ли выделенный элемент файлом
                    if (File.Exists((string)listView1.SelectedItems[i].Tag))
                        File.Delete((string)listView1.SelectedItems[i].Tag);
                }
                FillByFiles(currentFolderPath);
            }
        }

        //copy to clipboard
        private void copyToClipboardToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            copyPathToClipboard();
            copiedToClipboard = true;
        }

        //cut to clipboard
        private void cutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            copyPathToClipboard();
            copiedToClipboard = false;
        }

        //метод копирования путей к выделенным файлам, в буфер обмена
        public void copyPathToClipboard()
        {
            //заполняем массив строк, которые содержат в себе пути к выделенным файлам
            string[] path = new string[listView1.SelectedItems.Count];
            for (int i = 0; i < listView1.SelectedItems.Count; i++)
            {
                path[i] = (string)listView1.SelectedItems[i].Tag;
            }
            //помещаем данный массив в буфер обмена
            StringCollection str = new StringCollection();
            str.AddRange(path);
            Clipboard.SetFileDropList(str);
        }

        //paste from clipboard
        private void pasteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                IDataObject obj = Clipboard.GetDataObject();
                if (obj.GetDataPresent(DataFormats.FileDrop))
                {
                    //получаем список путей к файлам из буфера обмена
                    StringCollection files = Clipboard.GetFileDropList();

                    //копируем файлы в текущую папку
                    //путь к текущей папке хранится в currentFolderPath (ранее записан в момент нажатия на элемент treeView1)
                    foreach (string file in files)
                    {
                        string destname = Path.GetFileName(file);
                        if (!File.Exists($@"{currentFolderPath}\{destname}"))
                        {
                            //если была нажата кнопка копирования, то копируем файлы
                            //если - нет, то перемещаем
                            if (copiedToClipboard == true)
                                File.Copy(file, $@"{currentFolderPath}\{destname}");
                            else if (copiedToClipboard == false)
                                File.Move(file, $@"{currentFolderPath}\{destname}");
                        }
                        else
                            MessageBox.Show($"{destname} is already exist!");
                    }
                }
            }
            catch { }
            //перерисовываем listView1
            FillByFiles(currentFolderPath);
        }

        //search - не сделан
        private void searchToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Search search = new Search();
            search.Owner = this;
            search.Show();
        }
    }
}
